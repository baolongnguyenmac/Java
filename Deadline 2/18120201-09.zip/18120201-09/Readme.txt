0. Thông tin sinh viên
	0.1. Họ tên: Nguyễn Bảo Long
	0.2. MSSV: 18120201
	0.3. Email: 18120201@student.hcmus.edu.vn

1. Thư viện dùng trong chương trình 
	1.1. Thư viện JAXB: Sử dụng cho việc đọc file *.xml
2. Database chương trình
	2.1. Các file ghi dưới duạng UTF-8 WITHOUT BOM
	2.2. Do đó cần định dạng lại 2 file từ điển thành dạng UTF-8 WITHOUT BOM
3. Chạy chương trình
	3.1. Vào thư mục Release
	3.2. Gõ lệnh: java -jar Dictionary.jar
4. Tự đánh giá các chức năng được yêu cầu thực hiện
	4.1. Chuyển đổi ngôn ngữ tra cứu (tiếng Anh -> tiếng Việt và ngược lại): Hoàn thành
	4.2. Tra cứu và hiển thị nghĩa của từ: Hoàn thành
	4.3. Thêm từ và nghĩa của từ vào từ điển: Hoàn thành
	4.4. Xoá một từ và nghĩa của từ đó ra khỏi từ điển: Hoàn thành
	4.5. Lưu lại danh sách từ yêu thích và sắp xếp theo thứ tự A-Z/Z-A: Hoàn thành
	4.6. Thống kê tần suất tra cứu của các từ theo thời gian từ Date1 đến Date2 (Date1 và Date2 được nhập vào từ bàn phím) và hiển thị bảng thống kê: Hoàn thành
