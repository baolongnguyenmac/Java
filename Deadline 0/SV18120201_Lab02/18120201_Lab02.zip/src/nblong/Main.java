package nblong;

public class Main {
    public static void main(String[] args) throws Exception {
        Exercise01.calculate();
        Exercise02.calculate();
        Exercise03.calculate();
        Exercise04.calculate();
        Exercise05.calculate();
        Exercise06.calculate();
        Exercise07.calculate();
        Exercise08.calculate();
        Exercise09.calculate();
        Exercise10.calculate();
        Exercise11.calculate();
        Exercise12.calculate();
        Exercise13.calculate();
        Exercise14.calculate();
        Exercise15.calculate();
        Exercise16.calculate();
        Exercise17.calculate();
        Exercise18.calculate();
        Exercise19.calculate();
        Exercise20.calculate();
        Exercise21.calculate();
        Exercise22.reverse();
        Exercise25.binarySearch();
        Exercise26.solve();
        Exercise27.solve();
        Exercise28.handleCollision();
        Exercise29.e29();
        Exercise30.findTheLongestString();
        System.out.println(Exercise31.superString());
        Exercise28.handleCollision();
        if (Exercise31.superString()) {
            System.out.println("true");
        }
        else {
            System.out.println("false");
        }
        Exercise30.findTheLongestString();
    }
}